# OnlyViz 各图所需参数

操作步骤、列类型和最小 CSV 见 [图表操作手册](./chart-operation-manual.md)。

与 CLI `onlyviz-cli charts` / `onlyviz-cli params <type>`、API `GET /v1/charts` 同源（`tools/onlyviz-cli/lib/chart-catalog.mjs`）。

## 如何传参

```bash
# 官方参数名（推荐）
onlyviz-cli create --data data.csv --chart scatter --map x_axis=height,y_axis=weight --out fig.onlyviz

# 单独 flag
onlyviz-cli create --data data.csv --chart bar --x_axis cat --value sales --out fig.onlyviz

# 短别名：x→x_axis，y→y_axis；柱/折线等需要 value 时 y→value
onlyviz-cli create --data data.csv --chart bar --map x=cat,y=sales --out fig.onlyviz

# 可选样式
onlyviz-cli create --data data.csv --chart histogram --map value=score --style bins=20,showCurve=true
```

查看某图详情（用途、必填/可选字段、数据形状、样式键含义）：

```bash
onlyviz-cli params scatter
onlyviz-cli params sankey --json
```

## 参数名中文对照

| key | 含义 |
|-----|------|
| `x_axis` | X轴字段 |
| `y_axis` | Y轴字段 |
| `value` | 数值字段 |
| `group` | 分组字段 |
| `category` | 分类字段 |
| `size` | 大小字段 |
| `stage` | 阶段字段 |
| `word` | 词语字段 |
| `source` | 来源字段 |
| `target` | 目标字段 |
| `date` | 日期字段 |
| `lag` | 滞后字段 |
| `acf` | ACF 字段 |
| `pacf` | PACF 字段 |
| `ranges` | 区间字段 |
| `task` | 任务字段 |
| `startDate` | 开始日期 |
| `endDate` | 结束日期 |
| `dimensions` | 维度字段（多列用 `\|`） |
| `variables` | 变量字段（多列用 `\|`） |
| `barValue` | 柱数值字段 |
| `lineValue` | 线数值字段 |
| `leftValue` | 左轴数值 |
| `rightValue` | 右轴数值 |
| `open` / `close` / `high` / `low` | 开高低收 |
| `entity` | 实体字段 |
| `weight` | 权重字段 |
| `label` | 特征名（火山图标注） |

## 图类型一览

### line

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `line` | 折线图 | `x_axis`, `value` | `x_axis=date,value=sales` |
| `smooth_line` | 平滑折线图 | `x_axis`, `value` | `x_axis=date,value=sales` |
| `multiline` | 多线图 | `x_axis`, `value`, `group` | `x_axis=date,value=sales,group=region` |
| `alpha_density_line` | 透明度密度折线图 | `x_axis`, `value`, `group` | `x_axis=date,value=sales,group=region` |
| `gradient_density_line` | 渐变密度折线图 | `x_axis`, `value`, `group` | `x_axis=date,value=sales,group=region` |
| `statistical_density_line` | 统计密度折线图 | `x_axis`, `value`, `group` | `x_axis=date,value=sales,group=region` |
| `area` | 面积图 | `x_axis`, `value` | `x_axis=date,value=sales` |

### scatter

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `scatter` | 散点图 | `x_axis`, `y_axis` | `x_axis=height,y_axis=weight` |
| `scatter_with_reference_line` | 带参考线散点图 | `x_axis`, `y_axis` | `x_axis=pred,y_axis=actual` |

### bubble

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `bubble` | 气泡图 | `x_axis`, `y_axis`, `size` | `x_axis=gdp,y_axis=life,size=pop` |

### bar

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `bar` | 柱状图 | `x_axis`, `value` | `x_axis=category,value=sales` |
| `grouped_bar` | 分组柱状图 | `x_axis`, `value`, `group` | `x_axis=year,value=sales,group=region` |
| `stacked_bar` | 堆叠柱状图 | `x_axis`, `value`, `group` | `x_axis=year,value=sales,group=region` |
| `side_by_side_bar` | 并排柱状图 | `x_axis`, `value`, `group` | `x_axis=year,value=sales,group=region` |
| `bar_in_bar` | 嵌套柱状图 | `x_axis`, `value`, `group` | `x_axis=category,value=amount,group=period` |
| `symmetric_bar` | 对称条形图 | `x_axis`, `value`, `group` | `x_axis=pathway,value=genes,group=direction` |

### pie

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `pie` | 饼图 | `category`, `value` | `category=region,value=sales` |
| `doughnut` | 甜甜圈图 | `category`, `value` | `category=region,value=sales` |

### polar

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `polar_area` | 极坐标面积图 | `category`, `value` | `category=region,value=sales` |

### radar

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `radar` | 雷达图 | `category`, `value` | `category=metric,value=score` |

### boxplot

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `boxplot` | 箱线图 | `value` | `value=score,group=class` |
| `violin_plot` | 小提琴图 | `value`, `group` | `value=score,group=class` |
| `swarm_plot` | 蜂群图 | `value`, `group` | `value=score,group=class` |
| `boxplot_with_swarm` | 箱线图+蜂群图 | `value`, `group` | `value=score,group=class` |
| `boxen_plot` | 增强箱线图 | `value` | `value=score,group=class` |
| `notched_boxplot` | 带缺口箱线图 | `value`, `group` | `value=score,group=class` |
| `variable_width_boxplot` | 变宽箱线图 | `value`, `group` | `value=score,group=class` |

### histogram

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `histogram` | 直方图 | `value` | `value=score` |

### heatmap

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `heatmap` | 热力图 | `x_axis`, `y_axis`, `value` | `x_axis=row,y_axis=col,value=corr` |
| `calendar_heatmap` | 日历热力图 | `date`, `value` | `date=day,value=count` |

### waterfall

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `waterfall` | 瀑布图 | `category`, `value` | `category=step,value=delta` |

### funnel

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `funnel` | 漏斗图 | `stage`, `value` | `stage=step,value=users` |

### wordcloud

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `word_cloud` | 词云图 | `word`, `value` | `word=term,value=freq` |

### treemap

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `treemap` | 树状图 | `category`, `value` | `category=segment,value=sales` |

### sankey

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `sankey` | 桑基图 | `source`, `target`, `value` | `source=from,target=to,value=flow` |

### sunburst

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `sunburst` | 旭日图 | `category`, `value` | `category=path,value=amount` |

### correlogram

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `acf` | 自相关函数图 | `lag`, `acf` | `lag=lag,acf=acf` |
| `pacf` | 偏自相关函数图 | `lag`, `pacf` | `lag=lag,pacf=pacf` |

### migrated

| type | 名称 | 必填 | 示例 --map |
|------|------|------|------------|
| `multi_group_radar` | 多组雷达图 | `category`, `value`, `group` | `category=metric,value=score,group=team` |
| `percentage_stacked_bar` | 百分比堆叠柱状图 | `x_axis`, `value`, `group` | `x_axis=year,value=sales,group=region` |
| `pareto` | 帕累托图 | `category`, `value` | `category=cause,value=count` |
| `qq_plot` | QQ 图 | `value` | `value=score` |
| `residual_plot` | 残差图 | `x_axis`, `value` | `x_axis=fitted,value=residual` |
| `cdf_plot` | 累积分布图 | `value` | `value=score` |
| `stream` | 河流图 | `x_axis`, `value`, `group` | `x_axis=date,value=amount,group=topic` |
| `quadrant_chart` | 四象限图 | `x_axis`, `y_axis` | `x_axis=growth,y_axis=share` |
| `bullet_chart` | 子弹图 | `category`, `value`, `target`, `ranges` | `category=kpi,value=actual,target=goal,ranges=bands` |
| `control_chart` | 控制图 | `x_axis`, `value` | `x_axis=batch,value=measure` |
| `gantt` | 甘特图 | `task`, `startDate`, `endDate` | `task=name,startDate=start,endDate=end` |
| `parallel_coordinates` | 平行坐标图 | `dimensions` | `dimensions=a\|b\|c` |
| `combo` | 组合图 | `x_axis`, `barValue`, `lineValue` | `x_axis=month,barValue=sales,lineValue=margin` |
| `dual_y_axis_line` | 双 Y 轴折线图 | `x_axis`, `leftValue`, `rightValue` | `x_axis=date,leftValue=sales,rightValue=rate` |
| `candlestick` | K 线图 | `x_axis`, `open`, `close`, `high`, `low` | `x_axis=date,open=open,close=close,high=high,low=low` |
| `correlation_matrix` | 相关矩阵 | `variables` | `variables=a\|b\|c` |
| `scatterplot_matrix` | 散点矩阵 | `variables` | `variables=a\|b\|c` |
| `contour` | 等高线图 | `x_axis`, `y_axis`, `value` | `x_axis=x,y_axis=y,value=z` |
| `shared_entity_chord` | 共享实体弦图 | `group`, `entity` | `group=dept,entity=person` |
| `weight_shared_entity_chord` | 加权共享实体弦图 | `group`, `entity`, `weight` | `group=dept,entity=person,weight=hours` |
| `volcano` | 火山图 | `x_axis`, `y_axis` | `x_axis=log2FC,y_axis=pvalue,label=gene` |
| `metric` | 指标卡 | `value` | `value=amount` |
| `population_pyramid` | 背靠背柱图 | `x_axis`, `value`, `group` | `x_axis=age,value=n,group=sex` |

## 可选样式参数

通过 `--style key=value,...` 或 API `styleOptions` 传入。各图可选字段如下：

- **line**: `color`, `strokeWidth`, `showDots`, `showGrid`, `showLegend`
- **smooth_line**: `color`, `strokeWidth`, `showDots`, `showLegend`, `curveType`
- **multiline**: `colors`, `strokeWidth`, `showDots`, `showGrid`, `showLegend`
- **alpha_density_line**: `baseColor`, `alpha`, `strokeWidth`, `showDots`, `showGrid`, `showLegend`, `blendMode`
- **gradient_density_line**: `colorScheme`, `customColors`, `minDensityColor`, `maxDensityColor`, `strokeWidth`, `showDots`, `showGrid`, `showLegend`
- **statistical_density_line**: `bandwidth`, `kernelType`, `resolution`, `showOriginalLines`, `strokeWidth`, `showDots`, `showGrid`, `showLegend`
- **area**: `group`, `colors`, `strokeWidth`, `showFill`, `fillOpacity`, `useGradient`, `showDots`, `showLegend`, `smooth`
- **scatter**: `color`, `showGrid`, `showLegend`, `pointShape`, `minRadius`, `maxRadius`, `fillOpacity`, `showBorder`, `borderColor`, `borderWidth`
- **scatter_with_reference_line**: `referenceAngle`, `referenceLineColor`, `referenceLineWidth`, `referenceLineStyle`, `showDeviation`, `deviationColor`, `pointShape`, `pointColor`, `pointSize`, `fillOpacity`, `showBorder`, `borderColor`, `borderWidth`, `showGrid`, `showLegend`
- **bubble**: `color`, `showGrid`, `showLegend`
- **bar**: `color`, `showGrid`, `showLegend`, `horizontal`
- **grouped_bar**: `colors`, `showGrid`, `showLegend`, `horizontal`
- **stacked_bar**: `colors`, `showGrid`, `showLegend`, `showTotal`, `horizontal`
- **side_by_side_bar**: `colors`, `showGrid`, `showLegend`, `horizontal`
- **bar_in_bar**: `innerBarColor`, `outerBarColor`, `innerBarWidth`, `showGrid`, `showLegend`, `horizontal`
- **symmetric_bar**: `symmetricAbout`（`y` 左右 / `x` 上下）, `positiveGroup`, `negativeGroup`, `positiveColor`, `negativeColor`, `showCenterLine`, `showValues`, `showGrid`, `showLegend`
- **pie**: `colors`, `showLegend`, `showLabels`, `showValues`, `showPercentages`, `innerRadius`, `outerRadius`, `padAngle`, `labelPosition`
- **doughnut**: `colors`, `showLegend`, `showLabels`, `showValues`, `showPercentages`, `innerRadius`, `outerRadius`, `padAngle`, `labelPosition`
- **polar_area**: `colors`, `showLegend`, `showLabels`, `showValues`, `showPercentages`, `innerRadius`, `outerRadius`, `padAngle`, `labelPosition`
- **radar**: `group`, `colors`, `showGrid`, `showLegend`
- **boxplot**: `group`, `showOutliers`, `whiskerLength`, `boxWidth`, `colors`, `showGrid`, `showLegend`, `horizontal`
- **violin_plot**: `bandwidth`, `kernelType`, `showBoxplot`, `colors`, `fillOpacity`, `showGrid`, `showLegend`, `horizontal`
- **swarm_plot**: `pointSize`, `pointSpacing`, `showBorder`, `borderColor`, `colors`, `showGrid`, `showLegend`, `horizontal`
- **boxplot_with_swarm**: `showOutliers`, `whiskerLength`, `pointSize`, `pointSpacing`, `boxOpacity`, `colors`, `showGrid`, `showLegend`, `horizontal`
- **boxen_plot**: `group`, `kLevels`, `scaleFactor`, `showOutliers`, `colors`, `showGrid`, `showLegend`, `horizontal`
- **notched_boxplot**: `confidenceLevel`, `notchWidth`, `showOutliers`, `whiskerLength`, `colors`, `showGrid`, `showLegend`, `horizontal`
- **variable_width_boxplot**: `widthScale`, `minWidth`, `maxWidth`, `showOutliers`, `whiskerLength`, `colors`, `showGrid`, `showLegend`, `horizontal`
- **histogram**: `group`, `bins`, `binWidth`, `showDensity`, `showCurve`, `colors`, `showGrid`, `showLegend`
- **heatmap**: `colorScheme`, `customColors`, `showValues`, `showLabels`, `showGrid`
- **calendar_heatmap**: `colorScheme`, `customColors`, `showValues`, `cellSize`, `cellPadding`, `startDate`, `endDate`, `showGrid`
- **waterfall**: `type`, `increaseColor`, `decreaseColor`, `totalColor`, `showConnectors`, `showValues`, `showGrid`
- **funnel**: `showConversionRate`, `showValues`, `showPercentages`, `orientation`, `colors`, `showGrid`
- **word_cloud**: `minFontSize`, `maxFontSize`, `fontFamily`, `rotation`, `spiral`, `padding`, `colors`, `showGrid`
- **treemap**: `tile`, `padding`, `paddingInner`, `paddingOuter`, `showLabels`, `showValues`, `colors`, `showGrid`
- **sankey**: `nodeWidth`, `nodePadding`, `linkOpacity`, `nodeAlign`, `showLabels`, `colors`, `showGrid`
- **sunburst**: `innerRadius`, `outerRadius`, `padAngle`, `showLabels`, `showValues`, `showPercentages`, `colors`, `showGrid`
- **acf**: `title`, `color`, `confidenceInterval`, `showConfidenceInterval`, `showGrid`
- **pacf**: `title`, `color`, `confidenceInterval`, `showConfidenceInterval`, `showGrid`
- **multi_group_radar**: `colors`, `showGrid`, `showLegend`
- **percentage_stacked_bar**: `colors`, `showGrid`, `showLegend`, `showTotal`, `horizontal`
- **pareto**: `barColor`, `lineColor`, `showGrid`, `showLegend`, `showValues`
- **qq_plot**: `group`, `color`, `showGrid`, `showLegend`
- **residual_plot**: `group`, `showSmooth`, `showGrid`, `showLegend`, `color`
- **cdf_plot**: `group`, `colors`, `showGrid`, `showLegend`
- **stream**: `colors`, `offset`, `showLegend`
- **quadrant_chart**: `group`, `split`, `showGrid`, `showLegend`, `color`
- **bullet_chart**: `valueColor`, `targetColor`, `showLegend`
- **control_chart**: `sigma`, `showZones`, `showGrid`, `color`
- **gantt**: `group`, `progress`, `colors`, `showLegend`
- **parallel_coordinates**: `group`, `colors`, `showLegend`
- **combo**: `group`, `dualAxis`, `colors`, `showLegend`, `showGrid`
- **dual_y_axis_line**: `group`, `colors`, `showLegend`, `showGrid`
- **candlestick**: `volume`, `upColor`, `downColor`, `showGrid`
- **correlation_matrix**: `showValues`, `colorScheme`
- **scatterplot_matrix**: `group`, `colors`, `showLegend`
- **contour**: `thresholds`, `colorScheme`, `showGrid`
- **shared_entity_chord**: `colors`, `showLabels`
- **weight_shared_entity_chord**: `colors`, `showLabels`
- **volcano**: `label`, `yMode`, `fcCutoff`, `pCutoff`, `upColor`, `downColor`, `nsColor`, `showThresholds`, `showLabels`, `labelTopN`
- **metric**: `aggregation`, `fontSize`, `fontWeight`, `color`, `showUnit`, `unit`, `unitPosition`, `caption`, `showCaption`, `showAggregationLabel`, `align`, `valueDecimals`
- **population_pyramid**: `leftGroup`, `rightGroup`, `leftColor`, `rightColor`, `showCenterLine`, `showValues`, `showGrid`, `showLegend`, `valueDecimals`
